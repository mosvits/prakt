<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 10.04.2015
 * Time: 15:09
 * Access to database phpmyadmin.ukraine.com.ua
 */
$host = "eshowcas.mysql.ukraine.com.ua";
$user = "eshowcas_work";
$pasw = "Work_RTF";
$dbname = "eshowcas_work";



?>