# prakt
Сайт практики та працевлаштування для студентів РТФ
@RA-41m

База даних:
https://docs.google.com/document/d/1ntwtvh_ESygR-cZ4_QFK7A-EqGt-8HMArmRBnscw-no/edit?usp=sharing