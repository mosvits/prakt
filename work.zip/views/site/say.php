<?php
/**
 * Created by PhpStorm.
 * User: fulladr
 * Date: 14.04.2015
 * Time: 19:33
 */
?>
<?php
use yii\helpers\Html;
?>
<?= Html::encode($message) ?>